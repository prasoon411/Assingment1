﻿export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    email:string;
    lastName: string;
    authdata?: string;
}